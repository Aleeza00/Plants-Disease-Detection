# Plant-Disease-Detection-using-opencv
This project offers an effective solution for detecting diseases in plants using computer vision techniques. It utilizes the power of OpenCV to analyze leaf images and accurately identify diseases. It also uses tkinter to show percentage of disease, this project can serve as a valuable resource for researchers, agronomists, and plant enthusiasts.
